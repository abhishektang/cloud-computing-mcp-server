# Cloud Computing Exam 2024

**Duration:** 3 hours  
**Total Marks:** 100

---

## Section A: Multiple Choice Questions (20 marks)

1. Which of the following is NOT a cloud service model?
   - A) IaaS
   - B) PaaS
   - C) SaaS
   - D) DaaS

2. What does virtualization enable in cloud computing?
   - A) Resource pooling
   - B) Better hardware utilization
   - C) Multi-tenancy
   - D) All of the above

---

## Section B: Short Answer Questions (30 marks)

1. Define cloud computing and list its five essential characteristics. (10 marks)

2. Compare and contrast public, private, and hybrid cloud deployment models. (10 marks)

3. Explain the concept of containerization and how it differs from traditional virtualization. (10 marks)

---

## Section C: Long Answer Questions (50 marks)

1. Discuss the architecture of a cloud-based application, including load balancing, auto-scaling, and database replication. (25 marks)

2. Analyze the security challenges in cloud computing and propose solutions for data protection, access control, and compliance. (25 marks)

---

*This is a sample exam paper. Replace with actual past papers.*
